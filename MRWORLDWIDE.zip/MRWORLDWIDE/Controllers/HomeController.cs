using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using MRWORLDWIDE.Models;
using Newtonsoft.Json;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using CountriesApp.Models;

namespace MRWORLDWIDE.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            string baseUrl = "https://restcountries.com/v3.1/all";

            using (var client = new HttpClient())
            {
                var response = await client.GetAsync(baseUrl);
                var stringContent = await response.Content.ReadAsStringAsync();

                var countries = JsonConvert.DeserializeObject<List<Country>>(stringContent);

                return View(countries);
            }
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult GetRandomCountry()
        {
            var countries = GetAllCountries().Result;

            if (countries == null || !countries.Any())
            {
                return Content("No hay países disponibles.");
            }

            var random = new Random();
            var randomCountry = countries[random.Next(countries.Count)];

            return RedirectToAction("ShowRandomCountry", new { countryName = randomCountry.Name.Common });

        }

        public IActionResult ShowRandomCountry(string countryName)
        {
            var countries = GetAllCountries().Result;

            if (countries == null || !countries.Any())
            {
                return Content("No hay países disponibles.");
            }

            var random = new Random();
            var randomCountry = countries[random.Next(countries.Count)];

            return View(randomCountry);
        }


        private async Task<List<Country>> GetAllCountries()
        {
            string baseUrl = "https://restcountries.com/v3.1/all";

            using (var client = new HttpClient())
            {
                var response = await client.GetAsync(baseUrl);
                var stringContent = await response.Content.ReadAsStringAsync();

                return JsonConvert.DeserializeObject<List<Country>>(stringContent);
            }
        }

        
    }
}
