using Newtonsoft.Json;
using System.Collections.Generic;

namespace CountriesApp.Models
{
    public class Country
    {
        [JsonProperty("name")]
        public Name Name { get; set; }

        [JsonProperty("population")]
        public long Population { get; set; }

        [JsonProperty("area")]
        public double? Area { get; set; }

        [JsonProperty("flags")]
        public Flags Flags { get; set; }
        
        [JsonProperty("languages")]
        public Dictionary<string, string> Languages { get; set; }
    }

    public class Name
    {
        [JsonProperty("common")]
        public string Common { get; set; }

        [JsonProperty("official")]
        public string Official { get; set; }
    }

    public class Flags
    {
        [JsonProperty("png")]
        public string Png { get; set; }
    }
}
