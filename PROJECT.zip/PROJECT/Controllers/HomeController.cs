using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using PROJECT.Models;
using Newtonsoft.Json;
using CountriesApp.Models;

namespace PROJECT.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }

    public async Task<IActionResult> Index()
        {
            string baseUrl = "https://restcountries.com/v3.1/all";

            using (var client = new HttpClient())
            {
                var response = await client.GetAsync(baseUrl);
                var stringContent = await response.Content.ReadAsStringAsync();

                var countries = JsonConvert.DeserializeObject<List<Country>>(stringContent);

                return View(countries);
            }
        }
}
