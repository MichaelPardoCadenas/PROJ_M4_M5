from flask import Flask, render_template, request
from pymongo import MongoClient
import matplotlib.pyplot as plt
import io
import base64
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi

# Configura la conexión a MongoDB Atlas con el nuevo URI correcto
uri = "mongodb+srv://hugomartin:uClaUeN89yUdCZDO@contaminacion.z3ufsjw.mongodb.net/?retryWrites=true&w=majority&appName=Contaminacion"

# Crear un nuevo cliente y conectarse al servidor
client = MongoClient(uri, server_api=ServerApi('1'))

# Enviar un ping para confirmar una conexión exitosa
try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print(e)

db = client.Contaminacion
calidad_aire_collection = db.CalidadAire
contaminantes_collection = db.Contaminantes
estaciones_collection = db.Estaciones

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    barrio = request.form['barrio']
    dia = int(request.form['dia'])

    # Encuentra las estaciones en el barrio especificado
    estaciones = estaciones_collection.find({"Nom_barri": barrio})
    estaciones_ids = [estacion['Estacio'] for estacion in estaciones]

    # Busca los datos de contaminación para las estaciones encontradas en el día especificado
    results = calidad_aire_collection.find({"ESTACIO": {"$in": estaciones_ids}, "DIA": dia})

    # Convertir resultados a lista para facilitar su manipulación en la plantilla
    results_list = list(results)

    # Organiza los datos por contaminante para el día específico
    data_by_contaminant = {}
    for data in results_list:
        contaminant = data['CODI_CONTAMINANT']
        if contaminant not in data_by_contaminant:
            data_by_contaminant[contaminant] = []
        data_by_contaminant[contaminant].append(data)

    # Genera el gráfico con colores diferentes
    plt.figure(figsize=(10, 6))  # Cambia el tamaño de la gráfica
    colors = ['b', 'g', 'r', 'c', 'm', 'y', 'k']  # Colores para las barras
    bar_width = 0.35  # Ancho de las barras
    index = 0  # Índice inicial para las barras
    legends = set()  # Para rastrear los contaminantes añadidos a la leyenda

    for i, (contaminant, data_list) in enumerate(data_by_contaminant.items()):
        color = colors[i % len(colors)]
        for data in data_list:
            h12_value = data['H12']
            try:
                h12_value = float(h12_value)  # Intenta convertir H12 a float
                plt.bar(index, h12_value, bar_width, color=color)
                plt.text(index, h12_value, f'{h12_value:.2f}', fontsize=8, ha='center')
                if contaminant not in legends:
                    legends.add(contaminant)
                    plt.bar(index, 0, bar_width, color=color, label=f'Contaminante {contaminant}')
            except ValueError:
                print(f"Valor no numérico encontrado en H12: {h12_value}")
            index += 1

    plt.title(f"Niveles de H12 en {barrio} el día {dia}")
    plt.xlabel("Contaminantes")
    plt.ylabel("H12 (Valor)")
    plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.15), ncol=3)  # Mueve la leyenda encima de la gráfica
    plt.xticks(rotation=45)  # Rota las etiquetas del eje x para mayor legibilidad
    plt.tight_layout()  # Ajusta automáticamente los márgenes
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()

    return render_template('results.html', results=results_list, plot_url=plot_url)

if __name__ == '__main__':
    app.run(debug=True)






